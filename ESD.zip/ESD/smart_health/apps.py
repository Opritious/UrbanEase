from django.apps import AppConfig


class SmartHealthConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'smart_health' 